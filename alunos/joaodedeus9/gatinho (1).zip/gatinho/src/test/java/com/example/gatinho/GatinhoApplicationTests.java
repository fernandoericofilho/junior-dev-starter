package com.example.gatinho;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GatinhoApplicationTests {

	@Test
	void contextLoads() {
	}

}
