package com.example.gatinho;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GatinhoApplication {

	public static void main(String[] args) {
		SpringApplication.run(GatinhoApplication.class, args);
	}

}
