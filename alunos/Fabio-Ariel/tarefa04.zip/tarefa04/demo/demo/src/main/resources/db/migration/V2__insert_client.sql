INSERT INTO client (name, email) VALUES ('João Silva', 'joao@exemplo.com');
INSERT INTO client (name, email) VALUES ('Maria Souza', 'maria@exemplo.com');
